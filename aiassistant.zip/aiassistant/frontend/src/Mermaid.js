// frontend/src/Mermaid.js
import React, { useEffect, useRef } from 'react';
import mermaid from 'mermaid';

const Mermaid = ({ chartDefinition }) => {
  const mermaidRef = useRef(null);

  useEffect(() => {
    if (mermaidRef.current && chartDefinition) {
      // Clear previous content
      mermaidRef.current.innerHTML = '';
      try {
        // Initialize Mermaid.js and render the chart
        // Use a unique ID for each diagram to prevent conflicts
        const id = `mermaid-chart-${Math.random().toString(36).substr(2, 9)}`;
        mermaidRef.current.id = id;

        // Use mermaid.render to get the SVG directly
        // mermaid.initialize({ startOnLoad: false }); // Ensure auto-rendering is off if needed

        mermaid.render(id, chartDefinition)
          .then(({ svg }) => {
            mermaidRef.current.innerHTML = svg;
          })
          .catch((error) => {
            console.error("Mermaid rendering error:", error);
            mermaidRef.current.innerHTML = `<pre class="text-red-500">Error rendering diagram: ${error.message}\n${chartDefinition}</pre>`;
          });

      } catch (e) {
        console.error("Mermaid initialization error:", e);
        mermaidRef.current.innerHTML = `<pre class="text-red-500">Mermaid library error: ${e.message}\n${chartDefinition}</pre>`;
      }
    }
  }, [chartDefinition]); // Re-render when chartDefinition changes

  return (
    <div ref={mermaidRef} className="mermaid-output flex justify-center items-center w-full h-full min-h-[200px]">
      {/* Fallback for when chartDefinition is empty or rendering fails */}
      {!chartDefinition && <p className="text-gray-500">Enter a brief to generate a diagram.</p>}
    </div>
  );
};

export default Mermaid;
