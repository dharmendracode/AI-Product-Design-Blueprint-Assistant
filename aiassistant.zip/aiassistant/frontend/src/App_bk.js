// frontend/src/App.js (updated imports and usage)
import React, { useState } from 'react';
import Mermaid from './Mermaid'; // Import the Mermaid component
import './App.css';

function App() {
  const [briefInput, setBriefInput] = useState('');
  const [structuredSpec, setStructuredSpec] = useState('');
  const [mermaidDiagram, setMermaidDiagram] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async () => {
    setLoading(true);
    setError(null);
    setStructuredSpec('');
    setMermaidDiagram('');

    try {
      const response = await fetch('http://127.0.0.1:8000/generate-blueprint/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: briefInput }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setStructuredSpec(data.structured_spec);
      setMermaidDiagram(data.mermaid_diagram);
    } catch (e) {
      setError(`Failed to fetch: ${e.message}`);
      console.error("Error fetching blueprint:", e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="App p-8 max-w-4xl mx-auto bg-gray-50 min-h-screen">
      <h1 className="text-4xl font-bold text-gray-800 mb-6 text-center">
        AI Product Design & Blueprint Assistant
      </h1>

      <div className="mb-8 p-6 bg-white rounded-lg shadow-md">
        <h2 className="text-2xl font-semibold text-gray-700 mb-4">
          Enter Product Feature Brief
        </h2>
        <textarea
          className="w-full p-3 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-gray-700"
          rows="6"
          placeholder="e.g., As a user, I want to register an account with my email and password, and then be able to log in securely. The system should store user data in a database and send a welcome email upon successful registration."
          value={briefInput}
          onChange={(e) => setBriefInput(e.target.value)}
        ></textarea>
        <button
          onClick={handleSubmit}
          className="mt-4 w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md transition duration-300 ease-in-out transform hover:scale-105"
          disabled={loading}
        >
          {loading ? 'Generating...' : 'Generate Blueprint'}
        </button>
        {error && <p className="text-red-600 mt-4 text-center">{error}</p>}
      </div>

      {(structuredSpec || mermaidDiagram) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="p-6 bg-white rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold text-gray-700 mb-4">
              Structured Specification
            </h2>
            <pre className="whitespace-pre-wrap font-mono text-sm bg-gray-100 p-4 rounded-md border border-gray-200 text-gray-800">
              {structuredSpec || 'No structured specification generated yet.'}
            </pre>
          </div>

          <div className="p-6 bg-white rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold text-gray-700 mb-4">
              System Diagram (Mermaid)
            </h2>
            <div className="mermaid-container bg-gray-100 p-4 rounded-md border border-gray-200 flex justify-center items-center overflow-auto">
              <Mermaid chartDefinition={mermaidDiagram} /> {/* Use the Mermaid component here */}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
