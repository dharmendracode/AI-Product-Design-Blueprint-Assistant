# backend/main.py
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import spacy
import json
import os
from dotenv import load_dotenv # Import load_dotenv for .env file support
import httpx # Import httpx for async HTTP requests
import logging # Import logging module
import traceback # Import traceback for full stack traces

# Configure logging to show detailed messages in the console
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Load environment variables from .env file (if you decide to use it later)
load_dotenv()

app = FastAPI(
    title="AI Product Design Assistant API",
    description="API for converting natural language briefs into structured specs and diagrams.",
    version="0.1.0"
)

# Configure CORS to allow frontend to communicate with backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # WARNING: Adjust this in production to your frontend URL (e.g., ["http://localhost:3000"])
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load spaCy model once on startup
try:
    nlp = spacy.load("en_core_web_sm")
    logging.info("spaCy model 'en_core_web_sm' loaded successfully.")
except OSError:
    logging.error("spaCy model 'en_core_web_sm' not found. Please run 'python -m spacy download en_core_web_sm'")
    nlp = None # Handle case where model isn't found

@app.get("/")
async def read_root():
    """
    Root endpoint for basic API health check.
    """
    return {"message": "Welcome to the AI Product Design Assistant API!"}

@app.post("/generate-blueprint/")
async def generate_blueprint(brief: dict):
    """
    Generates structured technical specs and Mermaid diagrams from a natural language brief.
    """
    user_input = brief.get("text", "").strip()

    if not user_input:
        raise HTTPException(status_code=400, detail="Input brief cannot be empty.")

    if nlp is None:
        raise HTTPException(status_code=500, detail="spaCy model not loaded. Please check backend setup.")

    # --- Step 1: Basic NLP with spaCy (Feature Extraction) ---
    doc = nlp(user_input)
    # entities = [(ent.text, ent.label_) for ent in doc.ents]
    # tokens = [token.text for token in doc]
    # You can process these further to create a more refined prompt for the LLM

    # --- Step 2: Call LLM for Structured Spec and Diagram Generation ---
    prompt = f"""
    Analyze the following product feature brief and generate two outputs:
    1. A structured technical specification (Markdown format)
    2. A Mermaid.js diagram (e.g., flowchart, sequence diagram, or class diagram) representing the system architecture or flow.

    Return the response as a JSON object with two keys: "structured_spec" and "mermaid_diagram".

    Product Feature Brief:
    "{user_input}"

    Example Mermaid.js Flowchart:
    graph TD
        A[Start] --> B(Process)
        B --> C{{Decision?}}
        C -- Yes --> D[End Yes]
        C -- No --> E[End No]

    Example Mermaid.js Sequence Diagram:
    sequenceDiagram
        participant User
        participant Frontend
        participant Backend
        User->>Frontend: Submit brief
        Frontend->>Backend: Request blueprint
        Backend-->>Frontend: Return blueprint
        Frontend->>User: Display results

    Example Mermaid.js Class Diagram:
    classDiagram
        class User {{
            +String username
            +String email
            +String passwordHash
            +register()
            +login()
        }}
        class Product {{
            +String name
            +String description
            +Float price
        }}
        User "1" -- "*" Product : owns

    Ensure the Mermaid.js diagram is syntactically correct and directly usable.
    """

    # Hardcoded API Key (for debugging, will switch to environment variable later)
    GEMINI_API_KEY = "AIzaSyAvMarfLocp_VAiDR0SZIyJSSLpO4U8TOM"
    GEMINI_API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GEMINI_API_KEY}"

    # Log the API key (first few characters for security) to confirm it's loaded
    logging.info(f"Using Gemini API Key (first 5 chars): {GEMINI_API_KEY[:5]}*****")


    payload = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseMimeType": "application/json",
            "responseSchema": {
                "type": "OBJECT",
                "properties": {
                    "structured_spec": {"type": "STRING"},
                    "mermaid_diagram": {"type": "STRING"}
                }
            }
        }
    }

    try:
        async with httpx.AsyncClient() as client:
            logging.info(f"Sending request to Gemini API: {GEMINI_API_URL}")
            response = await client.post(GEMINI_API_URL, json=payload, timeout=60.0) # Increased timeout to 60 seconds

            # Attempt to parse response as JSON for more detailed error messages
            response_json = None
            try:
                response_json = response.json()
                logging.info(f"Gemini API raw JSON response (Status {response.status_code}): {json.dumps(response_json, indent=2)}")
            except json.JSONDecodeError:
                logging.warning(f"Gemini API response is not JSON (Status {response.status_code}): {response.text}")
                # If it's not JSON, we'll still try to raise for status below

            response.raise_for_status() # This will raise an httpx.HTTPStatusError for 4xx/5xx responses

            # If we reach here, the status code was 2xx (success)
            # Now, parse the result to extract the structured_spec and mermaid_diagram
            candidates = response_json.get("candidates", [])
            if candidates and "content" in candidates[0]:
                parts = candidates[0]["content"].get("parts", [])
                if parts and "text" in parts[0]:
                    llm_json_text = parts[0]["text"]
                    try:
                        llm_json = json.loads(llm_json_text)
                        structured_spec = llm_json.get("structured_spec", "Could not generate structured spec.")
                        mermaid_diagram = llm_json.get("mermaid_diagram", "graph TD\n    A[Error] --> B[No Diagram generated by LLM]")
                        return {
                            "structured_spec": structured_spec,
                            "mermaid_diagram": mermaid_diagram
                        }
                    except json.JSONDecodeError as inner_e:
                        logging.error(f"Failed to parse inner LLM JSON: {inner_e}. Raw LLM text: {llm_json_text}")
                        raise HTTPException(status_code=500, detail=f"AI service returned malformed structured JSON: {inner_e}")
            
            logging.error(f"Invalid or empty 'candidates' structure from Gemini API: {response_json}")
            raise HTTPException(status_code=500, detail=f"Invalid response structure from Gemini API: {response_json}")

    except httpx.RequestError as e:
        # This catches network errors (e.g., DNS resolution failed, connection refused)
        logging.error(f"HTTPX Request Error connecting to Gemini API: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail=f"Failed to connect to AI service (network issue): {e}")
    except httpx.HTTPStatusError as e:
        # This catches HTTP errors (4xx or 5xx status codes from the API)
        logging.error(f"Gemini API returned HTTP error: Status {e.response.status_code} - Response: {e.response.text}", exc_info=True)
        try:
            error_details = e.response.json()
            error_message = error_details.get("error", {}).get("message", e.response.text)
            error_code = error_details.get("error", {}).get("code", e.response.status_code)
            raise HTTPException(status_code=error_code, detail=f"AI service error ({error_code}): {error_message}")
        except json.JSONDecodeError:
            # If the error response itself is not JSON
            raise HTTPException(status_code=e.response.status_code, detail=f"AI service error (Status {e.response.status_code}): {e.response.text}")
    except Exception as e:
        # Catch any other unexpected errors
        logging.error(f"An unexpected error occurred during AI generation: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"AI generation failed unexpectedly: {e}")

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000, reload=True)
